import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const BottomNav: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-dark-card/95 backdrop-blur-xl border-t border-dark-border z-50 safe-bottom">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-around py-2">
          <button
            onClick={() => navigate('/')}
            className={`flex flex-col items-center justify-center py-2 px-4 transition-colors min-h-[44px] min-w-[44px] ${
              isActive('/') ? 'text-primary' : 'text-gray-400'
            }`}
            aria-label="Home"
          >
            <i className={`fa fa-home text-xl mb-1 ${isActive('/') ? 'text-primary' : ''}`}></i>
            <span className="text-xs">Home</span>
          </button>

          <button
            onClick={() => navigate('/create')}
            className={`flex flex-col items-center justify-center py-2 px-4 transition-colors min-h-[44px] min-w-[44px] ${
              isActive('/create') ? 'text-primary' : 'text-gray-400'
            }`}
            aria-label="Create"
          >
            <i className={`fa fa-plus-circle text-xl mb-1 ${isActive('/create') ? 'text-primary' : ''}`}></i>
            <span className="text-xs">Create</span>
          </button>

          <button
            onClick={() => {
              const bookmarks = localStorage.getItem('bookmarks');
              console.log('Bookmarks:', bookmarks);
            }}
            className="flex flex-col items-center justify-center py-2 px-4 transition-colors text-gray-400 min-h-[44px] min-w-[44px]"
            aria-label="Bookmarks"
          >
            <i className="fa fa-bookmark text-xl mb-1"></i>
            <span className="text-xs">Saved</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default BottomNav;