import React from 'react';
import type { Emotion } from '../services/api';

interface EmotionFilterProps {
  emotions: Emotion[];
  selectedEmotions: string[];
  onToggle: (emotionId: string) => void;
}

const EmotionFilter: React.FC<EmotionFilterProps> = ({
  emotions,
  selectedEmotions,
  onToggle,
}) => {
  return (
    <div className="overflow-x-auto pb-2 scrollbar-hide">
      <div className="flex gap-2 min-w-max">
        {emotions.map((emotion) => (
          <button
            key={emotion.id}
            onClick={() => onToggle(emotion.id)}
            className={`emotion-chip whitespace-nowrap ${
              selectedEmotions.includes(emotion.id) ? 'active' : ''
            }`}
          >
            {emotion.name}
          </button>
        ))}
      </div>
    </div>
  );
};

export default EmotionFilter;