import React from 'react';
import type { Confession } from '../services/api';

interface ConfessionCardProps {
  confession: Confession;
  onClick: () => void;
}

const ConfessionCard: React.FC<ConfessionCardProps> = ({ confession, onClick }) => {
  const truncateText = (text: string, maxLength: number) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  };

  return (
    <div
      onClick={onClick}
      className="glass-card p-5 cursor-pointer transition-all duration-300 hover:shadow-glow-primary hover:-translate-y-1 active:translate-y-0 w-full"
    >
      {confession.title && (
        <h3 className="text-lg font-semibold mb-2 text-white break-words">
          {truncateText(confession.title, 80)}
        </h3>
      )}

      {confession.audio_url && (
        <div className="mb-3 flex items-center gap-2 text-secondary">
          <i className="fa fa-microphone"></i>
          <span className="text-sm">Audio confession</span>
        </div>
      )}

      <p className="text-gray-300 mb-4 leading-relaxed break-words">
        {truncateText(confession.content, 200)}
      </p>

      {confession.emotions && confession.emotions.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {confession.emotions.slice(0, 3).map((emotion) => (
            <span
              key={emotion.id}
              className="px-3 py-1 bg-primary/20 text-primary rounded-full text-xs border border-primary/30"
            >
              {emotion.name}
            </span>
          ))}
          {confession.emotions.length > 3 && (
            <span className="px-3 py-1 bg-dark-card text-gray-400 rounded-full text-xs border border-dark-border">
              +{confession.emotions.length - 3} more
            </span>
          )}
        </div>
      )}

      <div className="flex items-center justify-between text-sm text-gray-500">
        <span>
          <i className="fa fa-eye mr-2"></i>
          {confession.view_count || 0} views
        </span>
        <span className="text-primary">
          Read more <i className="fa fa-arrow-right ml-1"></i>
        </span>
      </div>
    </div>
  );
};

export default ConfessionCard;