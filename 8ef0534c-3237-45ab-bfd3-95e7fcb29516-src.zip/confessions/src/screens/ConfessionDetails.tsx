import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  getConfessionById,
  getComments,
  createComment,
  getReactions,
  createReaction,
  getEmotions,
  textToSpeech,
  type Confession,
  type Comment,
  type Emotion,
  type Reaction,
} from '../services/api';

const ConfessionDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [confession, setConfession] = useState<Confession | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [emotions, setEmotions] = useState<Emotion[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      if (!id) return;

      setIsLoading(true);
      const [confessionData, commentsData, reactionsData, emotionsData] = await Promise.all([
        getConfessionById(id),
        getComments(id),
        getReactions(id),
        getEmotions(),
      ]);

      setConfession(confessionData);
      setComments(commentsData);
      setReactions(reactionsData);
      setEmotions(emotionsData);
      setIsLoading(false);
    };

    loadData();
  }, [id]);

  const handleReaction = async (emotionId: string) => {
    if (!id) return;

    const reaction = await createReaction(id, emotionId);
    if (reaction) {
      setReactions([...reactions, reaction]);
    }
  };

  const handleCommentSubmit = async () => {
    if (!id || !newComment.trim()) return;

    setIsSubmitting(true);
    const comment = await createComment(id, newComment.trim());
    if (comment) {
      setComments([...comments, comment]);
      setNewComment('');
    }
    setIsSubmitting(false);
  };

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: confession?.title || 'Anonymous Confession',
          text: confession?.content.substring(0, 100) + '...',
          url,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      navigator.clipboard.writeText(url);
      alert('Link copied to clipboard!');
    }
  };

  const handlePlayAudio = async () => {
    if (!confession?.content) return;

    if (audioUrl) {
      setIsPlayingAudio(!isPlayingAudio);
      return;
    }

    const url = await textToSpeech(confession.content);
    if (url) {
      setAudioUrl(url);
      setIsPlayingAudio(true);
    }
  };

  const getReactionCounts = () => {
    const counts: { [key: string]: number } = {};
    reactions.forEach((reaction) => {
      counts[reaction.emotion_id] = (counts[reaction.emotion_id] || 0) + 1;
    });
    return counts;
  };

  const reactionCounts = getReactionCounts();

  if (isLoading) {
    return (
      <div className="min-h-screen w-full bg-gradient-dark flex items-center justify-center">
        <div className="text-center">
          <i className="fa fa-spinner fa-spin text-4xl text-primary mb-4"></i>
          <p className="text-gray-400">Loading confession...</p>
        </div>
      </div>
    );
  }

  if (!confession) {
    return (
      <div className="min-h-screen w-full bg-gradient-dark flex items-center justify-center">
        <div className="text-center">
          <i className="fa fa-exclamation-circle text-6xl text-gray-600 mb-4"></i>
          <p className="text-gray-400 text-lg">Confession not found</p>
          <button onClick={() => navigate('/')} className="btn-primary mt-6">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-gradient-dark pb-8 safe-top safe-bottom">
      <div className="sticky top-0 z-40 bg-dark-bg/95 backdrop-blur-xl border-b border-dark-border safe-top">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate('/')}
              className="text-gray-400 hover:text-white transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Go back"
            >
              <i className="fa fa-arrow-left text-xl"></i>
            </button>
            <h1 className="text-xl font-bold text-gradient-primary">Confession</h1>
            <button
              onClick={handleShare}
              className="text-gray-400 hover:text-white transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Share"
            >
              <i className="fa fa-share-alt text-xl"></i>
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="glass-card p-6 mb-6">
          {confession.title && (
            <h2 className="text-2xl font-bold mb-4 text-white">{confession.title}</h2>
          )}

          {confession.audio_url && (
            <div className="mb-4 bg-dark-card rounded-xl p-4 border border-dark-border">
              <audio controls className="w-full">
                <source src={confession.audio_url} />
              </audio>
            </div>
          )}

          <p className="text-gray-300 text-lg leading-relaxed mb-4 whitespace-pre-wrap break-words">
            {confession.content}
          </p>

          <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
            <span>
              <i className="fa fa-eye mr-2"></i>
              {confession.view_count || 0} views
            </span>
            <button
              onClick={handlePlayAudio}
              className="text-secondary hover:text-secondary-light transition-colors min-h-[44px] px-4"
            >
              <i className={`fa fa-${isPlayingAudio ? 'pause' : 'play'} mr-2`}></i>
              {isPlayingAudio ? 'Pause' : 'Listen'}
            </button>
          </div>

          {confession.emotions && confession.emotions.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {confession.emotions.map((emotion) => (
                <span
                  key={emotion.id}
                  className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm border border-primary/30"
                >
                  {emotion.name}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="glass-card p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4 text-white">
            <i className="fa fa-heart mr-2 text-primary"></i>
            Reactions
          </h3>
          <div className="flex flex-wrap gap-2">
            {emotions.map((emotion) => (
              <button
                key={emotion.id}
                onClick={() => handleReaction(emotion.id)}
                className="emotion-chip hover:border-primary"
              >
                {emotion.name}
                {reactionCounts[emotion.id] && (
                  <span className="ml-2 text-xs bg-primary/30 px-2 py-0.5 rounded-full">
                    {reactionCounts[emotion.id]}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4 text-white">
            <i className="fa fa-comments mr-2 text-primary"></i>
            Comments ({comments.length})
          </h3>

          <div className="mb-4">
            <textarea
              placeholder="Share your thoughts anonymously..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="input-field min-h-[100px] resize-none mb-3"
              rows={3}
            />
            <button
              onClick={handleCommentSubmit}
              disabled={isSubmitting || !newComment.trim()}
              className="btn-primary w-full min-h-[44px]"
            >
              {isSubmitting ? (
                <>
                  <i className="fa fa-spinner fa-spin mr-2"></i>
                  Posting...
                </>
              ) : (
                <>
                  <i className="fa fa-paper-plane mr-2"></i>
                  Post Comment
                </>
              )}
            </button>
          </div>

          <div className="space-y-4">
            {comments.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No comments yet. Be the first to comment!</p>
            ) : (
              comments.map((comment) => (
                <div key={comment.id} className="bg-dark-card rounded-xl p-4 border border-dark-border">
                  <p className="text-gray-300 mb-2 break-words">{comment.content}</p>
                  <span className="text-xs text-gray-500">
                    <i className="fa fa-user-secret mr-1"></i>
                    Anonymous
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {audioUrl && (
        <audio
          src={audioUrl}
          autoPlay={isPlayingAudio}
          onEnded={() => setIsPlayingAudio(false)}
          className="hidden"
        />
      )}
    </div>
  );
};

export default ConfessionDetails;