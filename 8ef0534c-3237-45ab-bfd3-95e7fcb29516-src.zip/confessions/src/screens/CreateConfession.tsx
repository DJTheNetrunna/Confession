import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { createConfession, linkConfessionEmotion, getEmotions, uploadFile, transcribeAudio, type Emotion } from '../services/api';

const CreateConfession: React.FC = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isAudioMode, setIsAudioMode] = useState(false);
  const [audioUrl, setAudioUrl] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [emotions, setEmotions] = useState<Emotion[]>([]);
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const loadEmotions = async () => {
      const emotionsData = await getEmotions();
      setEmotions(emotionsData);
    };
    loadEmotions();
  }, []);

  const handleEmotionToggle = (emotionId: string) => {
    setSelectedEmotions(prev =>
      prev.includes(emotionId)
        ? prev.filter(id => id !== emotionId)
        : [...prev, emotionId]
    );
  };

  const handleAudioUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      setError('Please select an audio file');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const url = await uploadFile(file);
      if (url) {
        setAudioUrl(url);
        
        const transcription = await transcribeAudio(url);
        if (transcription) {
          setContent(transcription);
        }
      } else {
        setError('Failed to upload audio file');
      }
    } catch (err) {
      setError('Error uploading audio');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmit = async () => {
    if (!content.trim() && !audioUrl) {
      setError('Please write a confession or upload audio');
      return;
    }

    if (selectedEmotions.length === 0) {
      setError('Please select at least one emotion');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const confession = await createConfession({
        title: title.trim() || undefined,
        content: content.trim(),
        audio_url: audioUrl || undefined,
      });

      if (confession) {
        for (const emotionId of selectedEmotions) {
          await linkConfessionEmotion(confession.id, emotionId);
        }

        navigate('/');
      } else {
        setError('Failed to create confession');
      }
    } catch (err) {
      setError('Error creating confession');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-dark pb-8 safe-top safe-bottom">
      <div className="sticky top-0 z-40 bg-dark-bg/95 backdrop-blur-xl border-b border-dark-border safe-top">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate('/')}
              className="text-gray-400 hover:text-white transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Go back"
            >
              <i className="fa fa-arrow-left text-xl"></i>
            </button>
            <h1 className="text-xl font-bold text-gradient-primary">New Confession</h1>
            <div className="w-11"></div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="glass-card p-6 mb-6">
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => setIsAudioMode(false)}
              className={`flex-1 py-3 rounded-xl font-medium transition-all min-h-[44px] ${
                !isAudioMode
                  ? 'bg-gradient-primary text-white shadow-glow-primary'
                  : 'bg-dark-card text-gray-400 border border-dark-border'
              }`}
            >
              <i className="fa fa-keyboard mr-2"></i>
              Text
            </button>
            <button
              onClick={() => setIsAudioMode(true)}
              className={`flex-1 py-3 rounded-xl font-medium transition-all min-h-[44px] ${
                isAudioMode
                  ? 'bg-gradient-primary text-white shadow-glow-primary'
                  : 'bg-dark-card text-gray-400 border border-dark-border'
              }`}
            >
              <i className="fa fa-microphone mr-2"></i>
              Audio
            </button>
          </div>

          {!isAudioMode ? (
            <>
              <input
                type="text"
                placeholder="Title (optional)"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="input-field mb-4"
                maxLength={255}
              />
              <textarea
                placeholder="Share your confession anonymously..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="input-field min-h-[200px] resize-none"
                rows={8}
              />
            </>
          ) : (
            <div className="space-y-4">
              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*"
                onChange={handleAudioUpload}
                className="hidden"
              />
              
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isSubmitting}
                className="w-full btn-secondary min-h-[44px]"
              >
                <i className="fa fa-upload mr-2"></i>
                {audioUrl ? 'Change Audio File' : 'Upload Audio File'}
              </button>

              {audioUrl && (
                <div className="bg-dark-card rounded-xl p-4 border border-dark-border">
                  <div className="flex items-center gap-3 mb-3">
                    <i className="fa fa-check-circle text-secondary text-xl"></i>
                    <span className="text-sm text-gray-400">Audio uploaded successfully</span>
                  </div>
                  <audio controls className="w-full">
                    <source src={audioUrl} />
                  </audio>
                </div>
              )}

              {content && (
                <div className="bg-dark-card rounded-xl p-4 border border-dark-border">
                  <p className="text-sm text-gray-400 mb-2">Transcription:</p>
                  <p className="text-white">{content}</p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="glass-card p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4 text-white">
            <i className="fa fa-tags mr-2 text-primary"></i>
            Select Emotions
          </h2>
          <div className="flex flex-wrap gap-2">
            {emotions.map((emotion) => (
              <button
                key={emotion.id}
                onClick={() => handleEmotionToggle(emotion.id)}
                className={`emotion-chip ${
                  selectedEmotions.includes(emotion.id) ? 'active' : ''
                }`}
              >
                {emotion.name}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 rounded-xl p-4 mb-6">
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        )}

        <button
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="w-full btn-primary min-h-[44px]"
        >
          {isSubmitting ? (
            <>
              <i className="fa fa-spinner fa-spin mr-2"></i>
              Posting...
            </>
          ) : (
            <>
              <i className="fa fa-paper-plane mr-2"></i>
              Post Confession
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default CreateConfession;