import React from 'react';

const SplashScreen: React.FC = () => {
  return (
    <div className="min-h-screen w-full bg-gradient-dark flex items-center justify-center overflow-hidden">
      <div className="text-center animate-fade-in">
        <div className="relative mb-8">
          <div className="absolute inset-0 bg-gradient-primary blur-3xl opacity-50 animate-pulse-glow"></div>
          <i className="fa fa-comment-dots text-8xl text-gradient-primary relative z-10"></i>
        </div>
        
        <h1 className="text-5xl font-bold mb-4 text-gradient-primary">
          Confessions
        </h1>
        
        <p className="text-gray-400 text-lg max-w-md mx-auto px-4">
          A safe space for anonymous emotional expression
        </p>
        
        <div className="mt-12 flex justify-center gap-2">
          <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;