import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { getConfessions, getEmotions, type Confession, type Emotion } from '../services/api';
import ConfessionCard from '../components/ConfessionCard';
import EmotionFilter from '../components/EmotionFilter';
import BottomNav from '../components/BottomNav';

type FeedMode = 'latest' | 'trending' | 'random';

const MainFeed: React.FC = () => {
  const navigate = useNavigate();
  const [confessions, setConfessions] = useState<Confession[]>([]);
  const [filteredConfessions, setFilteredConfessions] = useState<Confession[]>([]);
  const [emotions, setEmotions] = useState<Emotion[]>([]);
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>([]);
  const [feedMode, setFeedMode] = useState<FeedMode>('latest');
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const loadEmotions = useCallback(async () => {
    const emotionsData = await getEmotions();
    setEmotions(emotionsData);
  }, []);

  const loadConfessions = useCallback(async () => {
    setIsLoading(true);
    const confessionsData = await getConfessions();
    setConfessions(confessionsData);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadEmotions();
    loadConfessions();
  }, [loadEmotions, loadConfessions]);

  useEffect(() => {
    let filtered = [...confessions];

    if (selectedEmotions.length > 0) {
      filtered = filtered.filter(confession => 
        confession.emotions?.some(e => selectedEmotions.includes(e.id))
      );
    }

    switch (feedMode) {
      case 'trending':
        filtered.sort((a, b) => (b.view_count || 0) - (a.view_count || 0));
        break;
      case 'random':
        filtered.sort(() => Math.random() - 0.5);
        break;
      case 'latest':
      default:
        filtered.sort((a, b) => {
          const dateA = new Date(a.created_at || 0).getTime();
          const dateB = new Date(b.created_at || 0).getTime();
          return dateB - dateA;
        });
        break;
    }

    setFilteredConfessions(filtered);
  }, [confessions, selectedEmotions, feedMode]);

  const handleScroll = useCallback(() => {
    if (
      window.innerHeight + document.documentElement.scrollTop
      >= document.documentElement.offsetHeight - 100
    ) {
      if (hasMore && !isLoading) {
        setPage(prev => prev + 1);
      }
    }
  }, [hasMore, isLoading]);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  const handleEmotionToggle = (emotionId: string) => {
    setSelectedEmotions(prev =>
      prev.includes(emotionId)
        ? prev.filter(id => id !== emotionId)
        : [...prev, emotionId]
    );
  };

  const handleConfessionClick = (id: string) => {
    navigate(`/confession/${id}`);
  };

  const handleCreateClick = () => {
    navigate('/create');
  };

  return (
    <div className="min-h-screen w-full bg-gradient-dark pb-24 safe-top safe-bottom">
      <div className="sticky top-0 z-40 bg-dark-bg/95 backdrop-blur-xl border-b border-dark-border safe-top">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gradient-primary">
              <i className="fa fa-comment-dots mr-2"></i>
              Confessions
            </h1>
          </div>

          <div className="flex gap-2 mb-4 overflow-x-auto pb-2 scrollbar-hide">
            <button
              onClick={() => setFeedMode('latest')}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all min-h-[44px] ${
                feedMode === 'latest'
                  ? 'bg-gradient-primary text-white shadow-glow-primary'
                  : 'bg-dark-card text-gray-400 border border-dark-border'
              }`}
            >
              <i className="fa fa-clock mr-2"></i>
              Latest
            </button>
            <button
              onClick={() => setFeedMode('trending')}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all min-h-[44px] ${
                feedMode === 'trending'
                  ? 'bg-gradient-primary text-white shadow-glow-primary'
                  : 'bg-dark-card text-gray-400 border border-dark-border'
              }`}
            >
              <i className="fa fa-fire mr-2"></i>
              Trending
            </button>
            <button
              onClick={() => setFeedMode('random')}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all min-h-[44px] ${
                feedMode === 'random'
                  ? 'bg-gradient-primary text-white shadow-glow-primary'
                  : 'bg-dark-card text-gray-400 border border-dark-border'
              }`}
            >
              <i className="fa fa-random mr-2"></i>
              Random
            </button>
          </div>

          <EmotionFilter
            emotions={emotions}
            selectedEmotions={selectedEmotions}
            onToggle={handleEmotionToggle}
          />
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {isLoading && confessions.length === 0 ? (
          <div className="flex justify-center items-center py-20">
            <div className="text-center">
              <i className="fa fa-spinner fa-spin text-4xl text-primary mb-4"></i>
              <p className="text-gray-400">Loading confessions...</p>
            </div>
          </div>
        ) : filteredConfessions.length === 0 ? (
          <div className="text-center py-20">
            <i className="fa fa-inbox text-6xl text-gray-600 mb-4"></i>
            <p className="text-gray-400 text-lg">No confessions found</p>
            <p className="text-gray-500 text-sm mt-2">Be the first to share</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredConfessions.map((confession) => (
              <ConfessionCard
                key={confession.id}
                confession={confession}
                onClick={() => handleConfessionClick(confession.id)}
              />
            ))}
          </div>
        )}
      </div>

      <button
        onClick={handleCreateClick}
        className="fixed bottom-24 right-4 w-14 h-14 bg-gradient-primary rounded-full shadow-glow-primary flex items-center justify-center transition-transform hover:scale-110 active:scale-95 z-30 safe-bottom"
        aria-label="Create confession"
      >
        <i className="fa fa-plus text-2xl text-white"></i>
      </button>

      <BottomNav />
    </div>
  );
};

export default MainFeed;