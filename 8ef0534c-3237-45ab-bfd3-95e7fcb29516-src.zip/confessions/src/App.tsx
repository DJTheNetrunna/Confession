import BrandingBadge from './components/BrandingBadge';
import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import SplashScreen from './screens/SplashScreen';
import MainFeed from './screens/MainFeed';
import CreateConfession from './screens/CreateConfession';
import ConfessionDetails from './screens/ConfessionDetails';
import { initializeUser } from './services/api';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const init = async () => {
      await initializeUser();
      setIsLoading(false);
      
      setTimeout(() => {
        setShowSplash(false);
      }, 2000);
    };

    init();
  }, []);

  if (isLoading || showSplash) {
    return <SplashScreen />;
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainFeed />} />
        <Route path="/create" element={<CreateConfession />} />
        <Route path="/confession/:id" element={<ConfessionDetails />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;