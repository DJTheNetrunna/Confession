const APP_ID = '3c12796d-3235-41ae-a274-b93e1099705c';
const BASE_URL = import.meta.env.DEV ? '/api' : 'https://deshawnn74tlf.lastapp.dev';

export interface User {
  id: string;
  provider: string;
  created_at: string;
}

export interface Emotion {
  id: string;
  name: string;
}

export interface Confession {
  id: string;
  title?: string;
  content: string;
  audio_url?: string;
  anonymous_id: string;
  ip_address?: string;
  is_flagged: boolean;
  is_deleted: boolean;
  view_count: number;
  created_at?: string;
  emotions?: Emotion[];
  reactions?: ReactionCount[];
}

export interface Comment {
  id: string;
  confession_id: string;
  content: string;
  anonymous_id: string;
  ip_address?: string;
  is_flagged: boolean;
  is_deleted: boolean;
  created_at?: string;
}

export interface Reaction {
  id: string;
  confession_id: string;
  emotion_id: string;
  anonymous_id: string;
  ip_address?: string;
}

export interface ReactionCount {
  emotion_id: string;
  emotion_name: string;
  count: number;
}

export interface AIResponse {
  response: string;
  emotions: string[];
  relatedConfessions: string[];
  supportResources: string;
}

const getAnonymousId = (): string => {
  let anonymousId = localStorage.getItem('anonymous_id');
  if (!anonymousId) {
    anonymousId = `anon_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('anonymous_id', anonymousId);
  }
  return anonymousId;
};

export const initializeUser = async (): Promise<void> => {
  try {
    const existingUser = localStorage.getItem('user_data');
    if (existingUser) {
      return;
    }

    const response = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'users',
        data: {
          provider: 'anonymous',
        },
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to initialize user');
    }

    const userData = await response.json();
    localStorage.setItem('user_data', JSON.stringify(userData));
  } catch (error) {
    console.error('Error initializing user:', error);
  }
};

export const getEmotions = async (): Promise<Emotion[]> => {
  try {
    const response = await fetch(
      `${BASE_URL}/data?app_id=${APP_ID}&table_name=emotions`
    );

    if (!response.ok) {
      throw new Error('Failed to fetch emotions');
    }

    const data = await response.json();
    
    if (!data || data.length === 0) {
      const defaultEmotions = [
        'sad', 'angry', 'lonely', 'hopeful', 'guilty', 
        'numb', 'anxious', 'relieved', 'confused', 'grateful'
      ];
      
      const createdEmotions: Emotion[] = [];
      for (const emotionName of defaultEmotions) {
        const created = await createEmotion(emotionName);
        if (created) {
          createdEmotions.push(created);
        }
      }
      return createdEmotions;
    }

    return data;
  } catch (error) {
    console.error('Error fetching emotions:', error);
    return [];
  }
};

export const createEmotion = async (name: string): Promise<Emotion | null> => {
  try {
    const response = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'emotions',
        data: { name },
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to create emotion');
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating emotion:', error);
    return null;
  }
};

export const getConfessions = async (): Promise<Confession[]> => {
  try {
    const response = await fetch(
      `${BASE_URL}/data?app_id=${APP_ID}&table_name=confessions`
    );

    if (!response.ok) {
      throw new Error('Failed to fetch confessions');
    }

    const data = await response.json();
    return data.filter((c: Confession) => !c.is_deleted && !c.is_flagged);
  } catch (error) {
    console.error('Error fetching confessions:', error);
    return [];
  }
};

export const getConfessionById = async (id: string): Promise<Confession | null> => {
  try {
    const confessions = await getConfessions();
    const confession = confessions.find(c => c.id === id);
    
    if (confession) {
      await updateConfession({
        ...confession,
        view_count: (confession.view_count || 0) + 1,
      });
    }
    
    return confession || null;
  } catch (error) {
    console.error('Error fetching confession:', error);
    return null;
  }
};

export const createConfession = async (
  confession: Partial<Confession>
): Promise<Confession | null> => {
  try {
    const anonymousId = getAnonymousId();
    
    const response = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'confessions',
        data: {
          ...confession,
          anonymous_id: anonymousId,
          is_flagged: false,
          is_deleted: false,
          view_count: 0,
        },
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to create confession');
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating confession:', error);
    return null;
  }
};

export const updateConfession = async (
  confession: Confession
): Promise<Confession | null> => {
  try {
    const response = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'confessions',
        data: confession,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to update confession');
    }

    return await response.json();
  } catch (error) {
    console.error('Error updating confession:', error);
    return null;
  }
};

export const linkConfessionEmotion = async (
  confessionId: string,
  emotionId: string
): Promise<void> => {
  try {
    await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'confession_emotions',
        data: {
          confession_id: confessionId,
          emotion_id: emotionId,
        },
      }),
    });
  } catch (error) {
    console.error('Error linking confession emotion:', error);
  }
};

export const getComments = async (confessionId: string): Promise<Comment[]> => {
  try {
    const response = await fetch(
      `${BASE_URL}/data?app_id=${APP_ID}&table_name=comments&confession_id=${confessionId}`
    );

    if (!response.ok) {
      throw new Error('Failed to fetch comments');
    }

    const data = await response.json();
    return data.filter((c: Comment) => !c.is_deleted && !c.is_flagged);
  } catch (error) {
    console.error('Error fetching comments:', error);
    return [];
  }
};

export const createComment = async (
  confessionId: string,
  content: string
): Promise<Comment | null> => {
  try {
    const anonymousId = getAnonymousId();
    
    const response = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'comments',
        data: {
          confession_id: confessionId,
          content,
          anonymous_id: anonymousId,
          is_flagged: false,
          is_deleted: false,
        },
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to create comment');
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating comment:', error);
    return null;
  }
};

export const getReactions = async (confessionId: string): Promise<Reaction[]> => {
  try {
    const response = await fetch(
      `${BASE_URL}/data?app_id=${APP_ID}&table_name=reactions&confession_id=${confessionId}`
    );

    if (!response.ok) {
      throw new Error('Failed to fetch reactions');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching reactions:', error);
    return [];
  }
};

export const createReaction = async (
  confessionId: string,
  emotionId: string
): Promise<Reaction | null> => {
  try {
    const anonymousId = getAnonymousId();
    
    const response = await fetch(`${BASE_URL}/data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        app_id: APP_ID,
        table_name: 'reactions',
        data: {
          confession_id: confessionId,
          emotion_id: emotionId,
          anonymous_id: anonymousId,
        },
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to create reaction');
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating reaction:', error);
    return null;
  }
};

export const uploadFile = async (file: File): Promise<string | null> => {
  try {
    const userData = localStorage.getItem('user_data');
    const user = userData ? JSON.parse(userData) : null;
    
    const formData = new FormData();
    formData.append('app_id', APP_ID);
    formData.append('user_id', user?.id || '');
    formData.append('file', file);

    const response = await fetch(`${BASE_URL}/data/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to upload file');
    }

    const data = await response.json();
    return data.url;
  } catch (error) {
    console.error('Error uploading file:', error);
    return null;
  }
};

export const moderateContent = async (text: string): Promise<AIResponse | null> => {
  try {
    const formData = new FormData();
    formData.append('app_id', APP_ID);
    formData.append('query', text);

    const response = await fetch(`${BASE_URL}/aiapi/answertext`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to moderate content');
    }

    return await response.json();
  } catch (error) {
    console.error('Error moderating content:', error);
    return null;
  }
};

export const transcribeAudio = async (audioUrl: string): Promise<string | null> => {
  try {
    const formData = new FormData();
    formData.append('app_id', APP_ID);
    formData.append('uid', '93004a1a68c60f4057ec49eaf3d4e4897831204888bab5c56a8c711818ef896a');
    formData.append('audio_url', audioUrl);

    const response = await fetch(`${BASE_URL}/aiapi/audio`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to transcribe audio');
    }

    const data = await response.json();
    return data.result;
  } catch (error) {
    console.error('Error transcribing audio:', error);
    return null;
  }
};

export const textToSpeech = async (text: string): Promise<string | null> => {
  try {
    const formData = new FormData();
    formData.append('app_id', APP_ID);
    formData.append('uid', 'c768e003adc70e6c5c0ee2380a586f2749ff83bdbcedb0038069ecae43f5d033');
    formData.append('prompt', text);

    const response = await fetch(`${BASE_URL}/aiapi/audio`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to convert text to speech');
    }

    const data = await response.json();
    return data.result;
  } catch (error) {
    console.error('Error converting text to speech:', error);
    return null;
  }
};